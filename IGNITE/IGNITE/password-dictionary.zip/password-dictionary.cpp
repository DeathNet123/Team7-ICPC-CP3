#include<bits/stdc++.h> 

using namespace std;


vector<string> clean_words_add(string word)
{
    string temp = "";
    vector<string> words_return;
    for(char c : word)
    {
        if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
        {
            temp += c;
        }
        else if(c == ',')
        {
            words_return.push_back(temp);
            temp = "";
        }
    }

    words_return.push_back(temp);
    return words_return;
}


bool if_angram(string str1, string str2)
{
    if(str1 == "")
        return false;
    sort(str1.begin(), str1.end());
    sort(str2.begin(), str2.end());
    transform(str1.begin(), str1.end(), str1.begin(), ::tolower);
    transform(str2.begin(), str2.end(), str2.begin(), ::tolower);

    if(str1 == str2)
        return true;
    else
        return false;

}
string getBruteforceDictionary(string inputstring)
{
    string return_string = "[";
    vector<string> words = clean_words_add(inputstring);
    for(int idx = 0; idx < words.size(); idx++)
    {
        if(words[idx] == "") continue;
        return_string = return_string + "{" + "\'" + words[idx] + "\'";
        for(int kdx = 0; kdx < words.size(); kdx++)
        {
            if(idx != kdx)
            {
                if(if_angram(words[kdx], words[idx]))
                {
                    return_string = return_string +','+ "\'" + words[kdx] + "\'";
                    words[kdx] = "";
                    words[idx] = "";
                }
            }
        }
        return_string = return_string + "},";
    }
    return_string = return_string.substr(0, return_string.size() - 1) + ']';
    return return_string;
}
int main(int argc, char** argv)
{

    string word;
    string output_word;
    ifstream words(argv[1]);
    ofstream words_file("output-ch2.txt");
    while(getline(words, word))
    {
        output_word = getBruteforceDictionary(word);
        words_file << output_word<<'\n';
    }
    
    words.close();
    words_file.close();
    return 0;
}