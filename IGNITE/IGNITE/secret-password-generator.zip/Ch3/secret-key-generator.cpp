#include <bits/stdc++.h>

using namespace std;

int main(int argc, char *argv[]){
    fstream file;
    file.open(argv[1]);
    string inputs;
    vector<string> nos;
    ofstream file1;
    file1.open("output-ch3.txt");
    while(getline(file,inputs)){
    stringstream input_stringstream(inputs);
    string i1;
    nos.clear();
    while(getline(input_stringstream,i1,',')){
        nos.push_back(i1);
    }
    for(string i:nos){
        int sum=0,x;
        for(int j=0;i[j]!='\0';j++){
            if(i[j]==' ')continue;
            x=int(i[j]) - '0';
            sum+=x;
        }
        while(sum>9){
        x=sum;
        sum=0;
        while(x>9){
            sum+=x%10;
            x/=10;
        }
        sum=sum+x;
        }
        file1 << sum << " ";
    }
    file1 << "\n";
    }
    
}
