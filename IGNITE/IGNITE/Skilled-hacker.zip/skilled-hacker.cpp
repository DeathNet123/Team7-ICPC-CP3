#include <bits/stdc++.h>

using namespace std;

string getSkilledHackers(string inputString){
    ofstream file1("output-ch4.txt");
    map <int,string> m;
    string s1=inputString.substr(1,inputString.find("],[")-1);
    inputString=inputString.substr(inputString.find("],[")+3,s1.length());
    stringstream s(s1),s2(inputString);
    while(getline(s,s1,',')){
        m.insert({atoi(s1.c_str()),"h1"});
    }
    while(getline(s2,s1,',')){
        m.insert({atoi(s1.c_str()),"h2"});
    }
    file1 << "[[";
    for(auto it:m)
        file1 << it.first << ',';
    file1.seekp(-1,ios::end);
    file1 << "],[[";
    int i=0;
    for(auto it=m.rbegin();i<3;i++,++it){
        file1 << it->second << ',' << it->first << "],[";
    }
    file1.seekp(-2,ios::end);
    file1 << "]]\n";
}

int main(int argc, char *argv[]){
    fstream file(argv[1]);
    string input,output;
    while(getline(file,input)){
        input=getSkilledHackers(input.substr(1,input.length()-2));
    }
    file.close();
}