#include <iostream>
#include<string>
#include <algorithm>
#include <fstream>
using namespace std;


string clean_password(string password_in)
{
    string clean = "";
    for(int idx = 0; idx < password_in.size(); idx++)
    {
        if(password_in[idx] != ' ')
            clean += password_in[idx];
    }

    return clean;
}

string remove_special(string temp)
{
    string news = "";
    for(int idx = 0; idx < temp.size(); idx++)
    {
        if((temp[idx] >= 'A' && temp[idx] <= 'Z') || (temp[idx] >= 'a' && temp[idx]<='z'))
            news += temp[idx];
    }

    return news;
}
string getNewPassword(string password_in)
{
    string temp = password_in;
    string cake = "";
    temp = remove_special(temp);
    reverse(temp.begin(), temp.end());
    for(int idx = 0; idx < password_in.size(); idx++)
    {
        cake = password_in[idx];
        if(!((password_in[idx] >= 'A' && password_in[idx] <= 'Z') || (password_in[idx] >= 'a' && password_in[idx] <= 'z')))
        {
            temp.insert(idx, cake);
        }
    }

    return temp;
}
int main(int argc, char **argv)
{
    string password_in;
    ifstream file_passwords(argv[1]);
    ofstream output_passwords("output-ch1.txt");
    while(getline(file_passwords, password_in))
    {
        password_in = clean_password(password_in);
        password_in =getNewPassword(password_in);
        output_passwords << password_in<<'\n';
    }
}